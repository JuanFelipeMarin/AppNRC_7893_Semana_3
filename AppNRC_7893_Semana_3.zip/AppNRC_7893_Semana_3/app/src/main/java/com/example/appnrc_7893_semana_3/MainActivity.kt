package com.example.appnrc_7893_semana_3

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.appnrc_7893_semana_3.ui.theme.AppNRC_7893_Semana_3Theme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            AppNRC_7893_Semana_3Theme {
                Scaffold(modifier = Modifier.fillMaxSize()) { innerPadding ->
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(innerPadding),
                        contentAlignment = Alignment.Center
                    ) {
                        GreetingWithButton()
                    }
                }
            }
        }
    }
}

@Composable
fun GreetingWithButton() {
    var message by remember { mutableStateOf("¡Hola, Android!") }

    Column(
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(
            text = message,
            fontSize = 24.sp
        )

        Spacer(modifier = Modifier.height(16.dp))

        Row {
            Button(onClick = { message = "¡Hola, Android!" }) {
                Text(text = "Inicio")
            }

            Spacer(modifier = Modifier.width(8.dp))
            Button(onClick = { message = "¡Botón presionado!" }) {
                Text(text = "Presionar")
            }
        }
    }
}

@Preview(showBackground = true)
@Composable
fun GreetingPreview() {
    AppNRC_7893_Semana_3Theme {
        Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            GreetingWithButton()
        }
    }
}
